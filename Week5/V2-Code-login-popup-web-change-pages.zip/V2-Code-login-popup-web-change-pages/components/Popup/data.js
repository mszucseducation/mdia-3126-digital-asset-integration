export const popup_data = {
    1:{
        head: "Welcome to my app",
        sub: "We're excited to help you"
    },
    2:{
        head: "We are all heroes",
        sub: "Especially you"
    },
    3:{
        head: "So be a part of greatness",
        sub: "by joining us"
    },
    4:{
        head: "Start by Logging in",
        sub: "Press on the button below"
    }
}