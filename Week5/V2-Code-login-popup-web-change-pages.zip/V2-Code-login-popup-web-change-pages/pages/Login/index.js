import { FlexBox} from "../../styles/globals";
import Menu from "../../components/Menu";

export default function Login() {
    return (
        <div>
            <FlexBox>
                <Menu/>
            </FlexBox>
            logged in now update
        </div>
    )
}
