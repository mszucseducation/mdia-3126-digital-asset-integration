import {useState} from 'react';
import axios from 'axios';

import {Avatar, Card, Title, Paragraph} from 'react-native-paper';
import * as Animatable from 'react-native-animatable';

import {View, Text, StatusBar, Button, ScrollView} from 'react-native';

export default function Animation() {
    const [numMovies, setNumMovies] = useState(0);
    const [movies, setMovies] = useState([]);

    const GetGhibliMovies  = async () => {
        const result = await axios.get("https://ghibliapi.herokuapp.com/films");
        console.log(result);
        setNumMovies(result.data.length);
        setMovies([
            ...result.data
        ]);
    }  

    return (
        <View>
            <Button onPress={() => GetGhibliMovies()} title="Get at Ghibli movies"/>

            <Text>There are #{numMovies} Movies from the DB</Text>
            <StatusBar style="auto"/>
            <ScrollView>
                {
                    numMovies > 0 && movies.map(
                        (o,i) => (
                            <Animatable.View
                                duration={1000}
                                delay={1000*i}
                                animation ={{
                                    from:{
                                        opacity: 0
                                    },
                                    to: {
                                        opacity: 1
                                    }
                                }} key={i}
                            >
                                <Card>
                                    <Card.Title title={o.title} subtitle={o.original_title}/>
                                    <Card.Content>
                                        <Paragraph>
                                            {o.description}
                                        </Paragraph>
                                    </Card.Content>
                                    <Card.Cover source={{ uri: o.image}} />
                                </Card>
                            </Animatable.View> 
                        )
                    )
                }
            </ScrollView>
        </View>
    )
}