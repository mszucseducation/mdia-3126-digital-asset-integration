import {motion} from 'framer-motion';
import {useState} from 'react';

export default function AnimationPage() {
    const [showDiv, setShowDiv] = useState(0);

    return (
        <div>
            <button onClick={() => setShowDiv(showDiv + 1 > 3 ? 1 : showDiv + 1)}>Click to see div</button>
            {
                showDiv >= 1 && <motion.div
                    style={{
                        textAlign:"center",
                        marginTop: 100
                    }}
                    initial={{
                        opacity:0,
                        scale:0,
                        x: -1000
                    }}
                    animate={{
                        opacity: 1,
                        scale: showDiv > 1 ? 1 : 5,
                        x: 0
                    }}
                    transition={{
                        duration: 10
                    }}>
                        Animation 1
                </motion.div>
            }
            {
                showDiv >= 2 && <motion.div
                    style={{
                        textAlign:"center",
                        marginTop: 100
                    }}
                    initial={{
                        opacity:0,
                        scale:0,
                        x: -1000
                    }}
                    animate={{
                        opacity: 1,
                        scale: showDiv > 2 ? 1 : 5,
                        x: 0
                    }}
                    transition={{
                        duration: 10
                    }}>
                        Animation 2
                </motion.div>
            }
            {
                showDiv >= 3 && <motion.div
                    style={{
                        textAlign:"center",
                        marginTop: 100
                    }}
                    initial={{
                        opacity:0,
                        scale:0,
                        x: -1000
                    }}
                    animate={{
                        opacity: 1,
                        scale: showDiv > 3 ? 1 : 5,
                        x: 0
                    }}
                    transition={{
                        duration: 10
                    }}>
                        Animation 3
                </motion.div>
            }
        </div>
    )
}