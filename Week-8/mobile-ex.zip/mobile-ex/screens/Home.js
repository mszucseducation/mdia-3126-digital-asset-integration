import {View, Text, Button} from 'react-native';

export default function Home({navigation}) {
    return(
        <View>
            <Text>Welcome to my app</Text>
            <Button title="Got to Animation" onPress={
                () => navigation.navigate("Ghibli")
            }/>
        </View>
    )
}